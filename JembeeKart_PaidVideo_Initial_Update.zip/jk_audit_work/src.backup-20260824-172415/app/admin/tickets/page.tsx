"use client";

export const dynamic = "force-dynamic";

import { useState } from "react";

import {
  Ticket,
  MessageSquare,
  CheckCircle,
  Clock3,
  XCircle
} from "lucide-react";

interface TicketItem {
  id: number;
  user: string;
  subject: string;
  status: string;
}

export default function TicketsPage() {

  const [tickets, setTickets] =
    useState<TicketItem[]>([
      {
        id: 1,
        user: "Rahul Kumar",
        subject: "Payment issue",
        status: "pending"
      },
      {
        id: 2,
        user: "Aman Ali",
        subject: "Order not delivered",
        status: "solved"
      },
      {
        id: 3,
        user: "Sneha Sharma",
        subject: "Affiliate commission",
        status: "rejected"
      }
    ]);

  function updateStatus(
    id: number,
    status: string
  ) {

    setTickets((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              status
            }
          : item
      )
    );
  }

  return (

    <main className="min-h-screen bg-[var(--color-page-background)] p-4 text-[var(--button-text-color)]">

      {/* HEADER */}

      <div className="mb-8 flex items-center gap-4">

        <div className="flex h-16 w-16 items-center justify-center rounded-[24px] bg-[var(--warning-color)]">

          <Ticket size={30} />

        </div>

        <div>

          <h1 className="text-3xl font-black">
            Support Tickets
          </h1>

          <p className="mt-1 text-sm text-[var(--muted-text-color)]">
            Manage customer support requests
          </p>

        </div>

      </div>

      {/* STATS */}

      <div className="mb-6 grid grid-cols-3 gap-4">

        <div className="rounded-[30px] bg-[var(--primary-color)] p-5">

          <Clock3
            size={28}
            className="text-[var(--warning-color)]"
          />

          <p className="mt-4 text-sm text-[var(--muted-text-color)]">
            Pending
          </p>

          <h2 className="mt-2 text-3xl font-black">
            14
          </h2>

        </div>

        <div className="rounded-[30px] bg-[var(--primary-color)] p-5">

          <CheckCircle
            size={28}
            className="text-[var(--success-color)]"
          />

          <p className="mt-4 text-sm text-[var(--muted-text-color)]">
            Solved
          </p>

          <h2 className="mt-2 text-3xl font-black">
            48
          </h2>

        </div>

        <div className="rounded-[30px] bg-[var(--primary-color)] p-5">

          <MessageSquare
            size={28}
            className="text-[var(--primary-color)]"
          />

          <p className="mt-4 text-sm text-[var(--muted-text-color)]">
            Total Tickets
          </p>

          <h2 className="mt-2 text-3xl font-black">
            62
          </h2>

        </div>

      </div>

      {/* TICKET LIST */}

      <div className="space-y-5">

        {tickets.map(
          (item) => (

            <div
              key={item.id}
              className="rounded-[30px] bg-[var(--primary-color)] p-5"
            >

              <div className="flex items-center justify-between gap-4">

                <div>

                  <h2 className="text-2xl font-black">
                    {item.user}
                  </h2>

                  <p className="mt-2 text-sm text-[var(--muted-text-color)]">
                    {item.subject}
                  </p>

                  <div className="mt-4 inline-block rounded-full bg-[var(--warning-color)] px-4 py-2 text-sm font-bold capitalize">

                    {item.status}

                  </div>

                </div>

                <div className="flex flex-wrap gap-3">

                  <button
                    onClick={() =>
                      updateStatus(
                        item.id,
                        "solved"
                      )
                    }
                    className="flex items-center gap-2 rounded-2xl bg-[var(--success-color)] px-5 py-3 text-sm font-bold"
                  >

                    <CheckCircle size={18} />

                    Solve

                  </button>

                  <button
                    onClick={() =>
                      updateStatus(
                        item.id,
                        "rejected"
                      )
                    }
                    className="flex items-center gap-2 rounded-2xl bg-[var(--danger-color)] px-5 py-3 text-sm font-bold"
                  >

                    <XCircle size={18} />

                    Reject

                  </button>

                </div>

              </div>

            </div>

          )
        )}

      </div>

      {/* PREVIEW */}

      <div className="mt-6 rounded-[30px] bg-gradient-to-r from-[var(--primary-color)] to-[var(--primary-color)] p-6">

        <h2 className="text-3xl font-black">
          Support Center
        </h2>

        <p className="mt-2 text-[var(--button-text-color)]/80">
          Customer issue management system
        </p>

      </div>

    </main>

  );
}
