import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    success: true,
    message: "Security event resolved.",
    resolvedAt: new Date().toISOString(),
  });
}
