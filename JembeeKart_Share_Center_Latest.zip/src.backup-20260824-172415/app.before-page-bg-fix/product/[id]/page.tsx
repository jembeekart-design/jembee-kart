"use client";

export const dynamic = "force-dynamic";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";

import {
  addDoc,
  collection,
  doc,
  getDoc
} from "firebase/firestore";

import {
  ArrowLeft,
  BadgeCheck,
  ChevronLeft,
  ChevronRight,
  Headphones,
  Heart,
  RotateCcw,
  Share2,
  ShieldCheck,
  ShoppingCart,
  Star,
  Store,
  Truck,
  Zap
} from "lucide-react";

import {
  TransformWrapper,
  TransformComponent
} from "react-zoom-pan-pinch";

import { db, auth } from "@/firebase/config";

interface Product {
  id: string;
  title?: string;
  description?: string;
  image?: string;
  images?: string[];
  category?: string;
  price?: number;
  discountPrice?: number;
  rating?: number;
  stock?: number;
  sizes?: string[];
  colors?: string[];
  coupons?: string[];
  seller?: {
    name?: string;
    rating?: number;
  };
}

export default function ProductPage() {
  const params = useParams();

  const productId = Array.isArray(params.id)
    ? params.id[0]
    : params.id;

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentImage, setCurrentImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState("M");
  const [selectedColor, setSelectedColor] = useState("var(--color-primary-button)");
  const [wishlist, setWishlist] = useState(false);
  const [showZoom, setShowZoom] = useState(false);

  const touchStartX = useRef(0);
  const touchEndX = useRef(0);

  useEffect(() => {
    async function fetchProduct() {
      try {
        const productRef = doc(db, "products", String(productId));
        const snapshot = await getDoc(productRef);

        if (snapshot.exists()) {
          const data = snapshot.data() as Omit<Product, "id">;

          setProduct({
            id: snapshot.id,
            ...data,
            images: data.images?.length
              ? data.images
              : data.image
              ? [data.image]
              : [],
            sizes: data.sizes || ["S", "M", "L", "XL", "XXL"],
            colors: data.colors || ["var(--color-primary-button)", "var(--color-primary-button)", "var(--color-primary-button)", "var(--color-primary-button)"],
            coupons: data.coupons || ["SAVE50", "FREESHIP", "EXTRA100"],
            seller: data.seller || {
              name: "JembeeKart Official",
              rating: 4.6
            }
          });
        }
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    }

    fetchProduct();
  }, [productId]);

  const discount = useMemo(() => {
    if (!product) return 0;
    return Math.round(
      (((product.price || 0) - (product.discountPrice || 0)) / (product.price || 1)) * 100
    );
  }, [product]);

  const deliveryDate = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() + 4);
    return date.toDateString();
  }, []);

 /* ======================================================
  ADD TO CART
  ====================================================== */
  async function addToCart() {
    if (!product) return;

    // Guest User Login Check
    if (!auth.currentUser) {
      router.push("/login");
      return;
    }

    try {
      // User-specific path: users/{uid}/cart
      const cartRef = collection(db, "users", auth.currentUser.uid, "cart");
      
      await addDoc(cartRef, {
        productId: product.id,
        title: product.title,
        image: product.images?.[0] || "/placeholder.png",
        price: product.price,
        discountPrice: product.discountPrice || null,
        quantity: 1,
        size: selectedSize || "N/A",
        color: selectedColor || "N/A"
      });
      
      alert("Added to Cart!");
    } catch (error) {
      console.error("Error adding to cart:", error);
      alert("Failed to add item to cart.");
    }
  }

  /* ======================================================
  BUY NOW (UPDATED ROUTING WITH ORDER REFERENCE ENGINE)
  ====================================================== */
  const router = useRouter();

function buyNow() {
  if (!product) return;

  router.push(
    `/checkout?productId=${product.id}`
  );
}

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[var(--color-primary-button)]">
        <h1 className="text-sm font-bold">Loading...</h1>
      </main>
    );
  }

  if (!product) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[var(--color-primary-button)]">
        <h1 className="text-sm font-bold text-[var(--color-danger)]">Product Not Found</h1>
      </main>
    );
  }

  const images = product.images || [];

  return (
    <main className="min-h-screen bg-[var(--color-primary-button)] pb-[85px]">
      {/* TOPBAR */}
      <div className="sticky top-0 z-50 bg-[var(--color-primary-button)]/90 backdrop-blur-md px-3 pt-3">
        <div className="flex items-center justify-between rounded-[18px] bg-[var(--color-card-background)] px-3 py-2.5 shadow-sm">
          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-page-background)]"
            >
              <ArrowLeft size={16} />
            </Link>
            <h1 className="text-[18px] font-black text-[var(--color-primary-button)]">JembeeKart</h1>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => setWishlist(!wishlist)}>
              <Heart
                size={18}
                fill={wishlist ? "red" : "transparent"}
                className={wishlist ? "text-[var(--color-danger)]" : ""}
              />
            </button>
            <button>
              <Share2 size={17} />
            </button>
          </div>
        </div>
      </div>

      <section className="space-y-4 px-3 pt-2">
        {/* IMAGE CONTROLLER */}
        <div className="rounded-[20px] bg-[var(--color-card-background)] p-2.5 shadow-sm">
          <div className="relative overflow-hidden rounded-[18px]">
            <img
              src={images[currentImage] || "/placeholder.png"}
              alt={product.title}
              onClick={() => setShowZoom(true)}
              onTouchStart={(e) => {
                touchStartX.current = e.targetTouches[0].clientX;
                touchEndX.current = e.targetTouches[0].clientX;
              }}
              onTouchMove={(e) => {
                touchEndX.current = e.targetTouches[0].clientX;
              }}
              onTouchEnd={() => {
                const distance = touchStartX.current - touchEndX.current;
                if (distance > 40) {
                  setCurrentImage((prev) =>
                    prev < images.length - 1 ? prev + 1 : prev
                  );
                }
                if (distance < -40) {
                  setCurrentImage((prev) => (prev > 0 ? prev - 1 : prev));
                }
              }}
              className="h-[240px] w-full rounded-[18px] bg-[var(--color-page-background)] object-cover cursor-zoom-in select-none"
            />

            <div className="absolute left-2 top-2 rounded-lg bg-[var(--color-danger)] px-2.5 py-1 text-[10px] font-bold text-[var(--button-text-color)]">
              {discount}% OFF
            </div>

            <button
              onClick={() => setWishlist(!wishlist)}
              className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-card-background)] shadow-sm"
            >
              <Heart
                size={16}
                fill={wishlist ? "red" : "transparent"}
                className={wishlist ? "text-[var(--color-danger)]" : ""}
              />
            </button>

            {currentImage > 0 && (
              <button
                onClick={() => setCurrentImage(currentImage - 1)}
                className="absolute left-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-[var(--color-card-background)] shadow-sm"
              >
                <ChevronLeft size={18} />
              </button>
            )}

            {currentImage < images.length - 1 && (
              <button
                onClick={() => setCurrentImage(currentImage + 1)}
                className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-[var(--color-card-background)] shadow-sm"
              >
                <ChevronRight size={18} />
              </button>
            )}

            <div className="absolute bottom-2 right-2 rounded-full bg-[var(--color-card-background)]/70 px-2 py-1 text-[10px] font-bold text-[var(--button-text-color)]">
              {currentImage + 1}/{images.length}
            </div>
          </div>

          {/* THUMBNAILS */}
          <div className="mt-3 flex gap-2 overflow-x-auto">
            {images.map((image, index) => (
              <button
                key={index}
                onClick={() => setCurrentImage(index)}
                className={`overflow-hidden rounded-lg border ${
                  currentImage === index ? "border-[var(--color-primary-button)]" : "border-transparent"
                }`}
              >
                <img src={image} alt="thumb" className="h-12 w-12 object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* METADATA DETAILS */}
        <div>
          <p className="text-[11px] font-bold text-[var(--color-primary-button)]">{product.category}</p>
          <h1 className="mt-1 text-[22px] font-black leading-[26px] text-[var(--text-primary)]">{product.title}</h1>

          <div className="mt-2 flex items-center gap-2 text-[11px]">
            <div className="flex items-center gap-1 text-[var(--color-success)]">
              <Star size={12} fill="green" />
              <span className="font-bold">{product.rating || 4.5}</span>
            </div>
            <span className="text-[var(--text-secondary)]">(128 Reviews)</span>
            <span className="text-[var(--text-primary)]">|</span>
            <span className="text-[var(--text-secondary)]">5k+ sold</span>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <h2 className="text-[24px] font-black leading-none">₹{product.discountPrice}</h2>
            <p className="text-[15px] font-bold text-[var(--text-secondary)] line-through">₹{product.price}</p>
          </div>

          <p className="mt-1 text-[13px] font-bold text-[var(--color-success)]">
            You save ₹{(product.price || 0) - (product.discountPrice || 0)} ({discount}%)
          </p>
        </div>

        {/* TRANSPORT & LOGISTICS */}
        <div className="rounded-[18px] bg-[var(--color-card-background)] p-3 shadow-sm">
          <div className="flex items-center gap-3">
            <Truck size={18} className="text-[var(--color-primary-button)]" />
            <div>
              <h3 className="text-sm font-bold text-[var(--color-primary-button)]">Free Delivery</h3>
              <p className="text-[11px] text-[var(--text-secondary)]">Delivery by {deliveryDate}</p>
            </div>
          </div>
        </div>

        {/* ATTRIBUTES SETUP */}
        <div>
          <h2 className="mb-2 text-sm font-bold">Select Size</h2>
          <div className="flex flex-wrap gap-2">
            {product.sizes?.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`min-w-[46px] rounded-[12px] border px-3 py-1.5 text-[12px] font-bold ${
                  selectedSize === size
                    ? "border-[var(--color-primary-button)] bg-[var(--color-primary-button)] text-[var(--button-text-color)]"
                    : "bg-[var(--color-card-background)]"
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-2 text-sm font-bold">Select Color</h2>
          <div className="flex gap-3">
            {product.colors?.map((color, index) => (
              <button
                key={`${color}-${index}`}
                onClick={() => setSelectedColor(color)}
                style={{ background: color }}
                className={`h-8 w-8 rounded-full border-2 ${
                  selectedColor === color ? "border-[var(--color-primary-button)]" : "border-[var(--color-border)]"
                }`}
              />
            ))}
          </div>
        </div>

        {/* SHIELD STATS */}
        <div className="grid grid-cols-2 gap-3 rounded-[18px] bg-[var(--color-card-background)] p-3 shadow-sm">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-[var(--color-success)]" />
            <div>
              <h3 className="text-[12px] font-bold">Original</h3>
              <p className="text-[10px] text-[var(--text-secondary)]">Authentic</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <RotateCcw size={18} className="text-[var(--color-primary-button)]" />
            <div>
              <h3 className="text-[12px] font-bold">7 Day Return</h3>
              <p className="text-[10px] text-[var(--text-secondary)]">Easy Return</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <BadgeCheck size={18} className="theme-primary-text" />
            <div>
              <h3 className="text-[12px] font-bold">Secure Payment</h3>
              <p className="text-[10px] text-[var(--text-secondary)]">Protected</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Headphones size={18} className="text-[var(--color-warning)]" />
            <div>
              <h3 className="text-[12px] font-bold">Support</h3>
              <p className="text-[10px] text-[var(--text-secondary)]">24/7 Help</p>
            </div>
          </div>
        </div>

        {/* SYSTEM MILESTONES */}
        <div className="space-y-3">
          <div className="rounded-[18px] bg-[var(--color-card-background)] p-4 shadow-sm">
            <div className="flex gap-3">
              <Truck size={18} className="text-[var(--color-success)]" />
              <div>
                <h3 className="text-sm font-bold">Delivery</h3>
                <p className="mt-1 text-[18px] font-black text-[var(--color-success)]">{deliveryDate}</p>
              </div>
            </div>
          </div>

          <div className="rounded-[18px] bg-[var(--color-card-background)] p-4 shadow-sm">
            <div className="flex gap-3">
              <Zap size={18} className="text-[var(--color-warning)]" />
              <div>
                <h3 className="text-sm font-bold">Cash on Delivery</h3>
                <p className="text-[11px] text-[var(--text-secondary)]">Pay when you receive</p>
              </div>
            </div>
          </div>
        </div>

        {/* VAULT OFFERS */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-[18px] font-black">Offers & Coupons</h2>
            <button className="text-xs font-bold text-[var(--color-primary-button)]">View All</button>
          </div>

          <div className="space-y-2">
            {product.coupons?.map((coupon) => (
              <div
                key={coupon}
                className="flex items-center justify-between rounded-[16px] border border-dashed border-[var(--color-primary-button)] bg-[var(--color-card-background)] px-3 py-3 shadow-sm"
              >
                <div>
                  <h3 className="text-[14px] font-black">{coupon}</h3>
                  <p className="mt-1 text-[10px] text-[var(--text-secondary)]">Extra discount available</p>
                </div>
                <button className="rounded-lg bg-gradient-to-r from-[var(--color-primary-button)] to-[var(--color-primary-button)] px-3 py-1.5 text-[10px] font-bold text-[var(--button-text-color)]">
                  Apply
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* SELLER STATS */}
        <div className="rounded-[18px] bg-[var(--color-card-background)] p-4 shadow-sm">
          <h2 className="text-[18px] font-black">Seller Details</h2>
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--color-primary-button)]">
                <Store size={18} className="text-[var(--color-primary-button)]" />
              </div>
              <div>
                <h3 className="text-[13px] font-black">{product.seller?.name}</h3>
                <p className="text-[11px] text-[var(--text-secondary)]">{product.seller?.rating}★ Seller Rating</p>
              </div>
            </div>
            <button className="rounded-xl border border-[var(--color-primary-button)] px-3 py-2 text-[11px] font-bold text-[var(--color-primary-button)]">
              View Store
            </button>
          </div>
        </div>

        {/* CORE MARKDOWN */}
        <div className="rounded-[18px] bg-[var(--color-card-background)] p-4 shadow-sm">
          <h2 className="text-[18px] font-black">Product Details</h2>
          <p className="mt-2 text-[12px] leading-6 text-[var(--text-secondary)]">{product.description}</p>
        </div>
      </section>

      {/* BOTTOM CONTROL GRID */}
      <div className="fixed bottom-0 left-0 z-50 w-full border-t bg-[var(--color-card-background)] px-3 py-2">
        <div className="flex items-center gap-2">
          <div>
            <h2 className="text-[20px] font-black">₹{product.discountPrice}</h2>
            <p className="text-[10px] font-bold text-[var(--color-success)]">{discount}% OFF</p>
          </div>

          <button
            onClick={addToCart}
            className="flex flex-1 items-center justify-center gap-1 rounded-[14px] border bg-[var(--color-card-background)] py-2 text-[12px] font-bold"
          >
            <ShoppingCart size={15} />
            Cart
          </button>

          <button
            onClick={buyNow}
            className="flex flex-1 items-center justify-center gap-1 rounded-[14px] bg-gradient-to-r from-[var(--color-primary-button)] to-[var(--color-primary-button)] py-2 text-[12px] font-bold text-[var(--button-text-color)]"
          >
            <Zap size={14} />
            Buy Now
          </button>
        </div>
      </div>

      {/* ZOOM LAYER OVERLAY CONTROL */}
      {showZoom && (
        <div className="fixed inset-0 z-[999] bg-[var(--color-card-background)]/95 backdrop-blur-sm select-none">
          <button
            onClick={() => setShowZoom(false)}
            className="absolute right-4 top-4 z-[1001] rounded-full bg-[var(--color-page-background)] p-2 text-[var(--text-primary)] font-bold shadow-md h-9 w-9 flex items-center justify-center"
          >
            ✕
          </button>

          <div className="relative flex h-full w-full items-center justify-center">
            <TransformWrapper
              initialScale={1}
              minScale={1}
              maxScale={4}
              centerOnInit={true}
            >
              {({ state }) => (
                <div className="relative h-full w-full flex items-center justify-center">
                  {state.scale === 1 && (
                    <div
                      className="absolute inset-0 z-[1000] bg-transparent cursor-grab active:cursor-grabbing"
                      onTouchStart={(e) => {
                        touchStartX.current = e.targetTouches[0].clientX;
                        touchEndX.current = e.targetTouches[0].clientX;
                      }}
                      onTouchMove={(e) => {
                        touchEndX.current = e.targetTouches[0].clientX;
                      }}
                      onTouchEnd={() => {
                        const distance = touchStartX.current - touchEndX.current;
                        if (distance > 45) {
                          setCurrentImage((prev) =>
                            prev < images.length - 1 ? prev + 1 : prev
                          );
                        }
                        if (distance < -45) {
                          setCurrentImage((prev) => (prev > 0 ? prev - 1 : prev));
                        }
                      }}
                    />
                  )}

                  <TransformComponent wrapperStyle={{ width: "100%", height: "100%" }}>
                    <div className="flex h-screen w-screen items-center justify-center bg-transparent">
                      <img
                        src={images[currentImage]}
                        alt="zoom-product"
                        className="max-h-screen max-w-full object-contain pointer-events-none"
                      />
                    </div>
                  </TransformComponent>
                </div>
              )}
            </TransformWrapper>
          </div>

          {currentImage > 0 && (
            <button
              onClick={() => setCurrentImage(currentImage - 1)}
              className="absolute left-3 top-1/2 z-[1001] flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-[var(--color-card-background)]/50 text-[var(--button-text-color)]"
            >
              <ChevronLeft size={24} />
            </button>
          )}

          {currentImage < images.length - 1 && (
            <button
              onClick={() => setCurrentImage(currentImage + 1)}
              className="absolute right-3 top-1/2 z-[1001] flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-[var(--color-card-background)]/50 text-[var(--button-text-color)]"
            >
              <ChevronRight size={24} />
            </button>
          )}
        </div>
      )}
    </main>
  );
}
