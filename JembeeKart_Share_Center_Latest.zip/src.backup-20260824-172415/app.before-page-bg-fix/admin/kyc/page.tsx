"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState } from "react";

import {
  doc,
  getDoc,
  setDoc
} from "firebase/firestore";

import {
  ShieldCheck,
  Save,
  FileText,
  BadgeCheck,
  Users,
  AlertTriangle,
  CheckCircle
} from "lucide-react";

import { db } from "@/firebase/config";

interface KYCSettings {
  kycEnabled: boolean;
  sellerKYC: boolean;
  affiliateKYC: boolean;
  autoApproveKYC: boolean;
  aadhaarRequired: boolean;
  panRequired: boolean;
  bankRequired: boolean;
  minimumAge: string;
}

export default function KYCPage() {

  const [settings, setSettings] =
    useState<KYCSettings>({
      kycEnabled: true,
      sellerKYC: true,
      affiliateKYC: true,
      autoApproveKYC: false,
      aadhaarRequired: true,
      panRequired: true,
      bankRequired: true,
      minimumAge: "18"
    });

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  useEffect(() => {

    fetchSettings();

  }, []);

  async function fetchSettings() {

    try {

      const ref = doc(
        db,
        "admin_settings",
        "kyc"
      );

      const snap =
        await getDoc(ref);

      if (snap.exists()) {

        setSettings(
          snap.data() as KYCSettings
        );

      }

    } catch (error) {

      console.log(error);

    } finally {

      setLoading(false);

    }
  }

  async function saveSettings() {

    try {

      setSaving(true);

      await setDoc(
        doc(
          db,
          "admin_settings",
          "kyc"
        ),
        settings
      );

      alert(
        "KYC Settings Saved"
      );

    } catch (error) {

      console.log(error);

    } finally {

      setSaving(false);

    }
  }

  function updateField(
    field: keyof KYCSettings,
    value: any
  ) {

    setSettings((prev) => ({
      ...prev,
      [field]: value
    }));
  }

  if (loading) {

    return (

      <div className="flex min-h-screen items-center justify-center bg-[var(--card-color)] text-[var(--button-text-color)]">

        Loading...

      </div>

    );
  }

  return (

    <main className="min-h-screen bg-[var(--primary-color)] p-4 text-[var(--button-text-color)]">

      {/* HEADER */}

      <div className="mb-8 flex items-center justify-between">

        <div className="flex items-center gap-4">

          <div className="flex h-16 w-16 items-center justify-center rounded-[24px] bg-[var(--success-color)]">

            <ShieldCheck size={30} />

          </div>

          <div>

            <h1 className="text-3xl font-black">
              KYC Verification
            </h1>

            <p className="mt-1 text-sm text-[var(--muted-text-color)]">
              Manage Aadhaar, PAN & verification settings
            </p>

          </div>

        </div>

        <button
          onClick={saveSettings}
          disabled={saving}
          className="flex items-center gap-2 rounded-2xl bg-[var(--success-color)] px-5 py-3 font-bold"
        >

          <Save size={18} />

          {saving
            ? "Saving..."
            : "Save"}

        </button>

      </div>

      {/* TOGGLES */}

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

        <ToggleCard
          title="KYC System"
          description="Enable KYC verification"
          icon={
            <ShieldCheck size={24} />
          }
          enabled={
            settings.kycEnabled
          }
          onClick={() =>
            updateField(
              "kycEnabled",
              !settings.kycEnabled
            )
          }
        />

        <ToggleCard
          title="Seller KYC"
          description="KYC required for sellers"
          icon={
            <Users size={24} />
          }
          enabled={
            settings.sellerKYC
          }
          onClick={() =>
            updateField(
              "sellerKYC",
              !settings.sellerKYC
            )
          }
        />

        <ToggleCard
          title="Affiliate KYC"
          description="KYC required for affiliates"
          icon={
            <BadgeCheck size={24} />
          }
          enabled={
            settings.affiliateKYC
          }
          onClick={() =>
            updateField(
              "affiliateKYC",
              !settings.affiliateKYC
            )
          }
        />

        <ToggleCard
          title="Auto Approve"
          description="Automatically approve KYC"
          icon={
            <CheckCircle size={24} />
          }
          enabled={
            settings.autoApproveKYC
          }
          onClick={() =>
            updateField(
              "autoApproveKYC",
              !settings.autoApproveKYC
            )
          }
        />

        <ToggleCard
          title="Aadhaar Required"
          description="Require Aadhaar card"
          icon={
            <FileText size={24} />
          }
          enabled={
            settings.aadhaarRequired
          }
          onClick={() =>
            updateField(
              "aadhaarRequired",
              !settings.aadhaarRequired
            )
          }
        />

        <ToggleCard
          title="PAN Required"
          description="Require PAN card"
          icon={
            <AlertTriangle size={24} />
          }
          enabled={
            settings.panRequired
          }
          onClick={() =>
            updateField(
              "panRequired",
              !settings.panRequired
            )
          }
        />

        <ToggleCard
          title="Bank Required"
          description="Require bank details"
          icon={
            <FileText size={24} />
          }
          enabled={
            settings.bankRequired
          }
          onClick={() =>
            updateField(
              "bankRequired",
              !settings.bankRequired
            )
          }
        />

      </div>

      {/* INPUTS */}

      <div className="mt-6">

        <InputCard
          title="Minimum Age"
          value={settings.minimumAge}
          onChange={(value: string) =>
            updateField(
              "minimumAge",
              value
            )
          }
        />

      </div>

      {/* STATUS */}

      <div className="mt-6 rounded-[30px] bg-gradient-to-r from-[var(--primary-color)] to-[var(--primary-color)] p-6">

        <div className="flex items-center gap-3">

          <ShieldCheck size={28} />

          <h2 className="text-3xl font-black">
            Verification Status
          </h2>

        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">

          <StatusCard
            title="KYC System"
            value={
              settings.kycEnabled
                ? "Enabled"
                : "Disabled"
            }
          />

          <StatusCard
            title="Seller KYC"
            value={
              settings.sellerKYC
                ? "Required"
                : "Disabled"
            }
          />

          <StatusCard
            title="Affiliate KYC"
            value={
              settings.affiliateKYC
                ? "Required"
                : "Disabled"
            }
          />

          <StatusCard
            title="Minimum Age"
            value={`${settings.minimumAge}+`}
          />

        </div>

      </div>

    </main>

  );
}

function InputCard({
  title,
  value,
  onChange
}: {
  title: string;
  value: string;
  onChange: (
    value: string
  ) => void;
}) {

  return (

    <div className="rounded-[30px] bg-[var(--primary-color)] p-5">

      <h2 className="mb-4 text-2xl font-black">
        {title}
      </h2>

      <input
        type="text"
        value={value}
        onChange={(e) =>
          onChange(
            e.target.value
          )
        }
        className="w-full rounded-2xl bg-[var(--card-color)] px-4 py-4 outline-none"
      />

    </div>

  );
}

function ToggleCard({
  title,
  description,
  icon,
  enabled,
  onClick
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  enabled: boolean;
  onClick: () => void;
}) {

  return (

    <div className="rounded-[30px] bg-[var(--primary-color)] p-5">

      <div className="flex items-center justify-between">

        <div className="flex items-center gap-3">

          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--card-color)]">

            {icon}

          </div>

          <div>

            <h2 className="text-xl font-black">
              {title}
            </h2>

            <p className="text-sm text-[var(--muted-text-color)]">
              {description}
            </p>

          </div>

        </div>

        <button
          onClick={onClick}
          className={`rounded-full px-5 py-3 text-sm font-bold ${
            enabled
              ? "bg-[var(--success-color)]"
              : "bg-[var(--danger-color)]"
          }`}
        >

          {enabled
            ? "Enabled"
            : "Disabled"}

        </button>

      </div>

    </div>

  );
}

function StatusCard({
  title,
  value
}: {
  title: string;
  value: string;
}) {

  return (

    <div className="rounded-2xl bg-[var(--card-color)]/10 p-4">

      <p className="text-sm text-[var(--button-text-color)]/70">
        {title}
      </p>

      <h3 className="mt-2 text-2xl font-black">
        {value}
      </h3>

    </div>

  );
}
