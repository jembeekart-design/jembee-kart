"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState } from "react";

import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  updateDoc
} from "firebase/firestore";

import {
  Wallet,
  IndianRupee,
  User,
  CheckCircle2,
  XCircle,
  Trash2,
  Clock3
} from "lucide-react";

import { db } from "@/firebase/config";

interface WithdrawalRequest {
  id?: string;
  userName: string;
  amount: number;
  method: string;
  account: string;
  status: string;
}

export default function WithdrawalRequestsPage() {

  const [requests, setRequests] =
    useState<WithdrawalRequest[]>([]);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {

    const q = query(
      collection(
        db,
        "withdrawal_requests"
      ),
      orderBy(
        "status",
        "asc"
      )
    );

    const unsubscribe =
      onSnapshot(q, (snapshot) => {

        const data:
          WithdrawalRequest[] = [];

        snapshot.forEach((doc) => {

          data.push({
            id: doc.id,
            ...doc.data()
          } as WithdrawalRequest);

        });

        setRequests(data);

        setLoading(false);

      });

    return () =>
      unsubscribe();

  }, []);

  async function updateStatus(
    id: string,
    status: string
  ) {

    try {

      await updateDoc(
        doc(
          db,
          "withdrawal_requests",
          id
        ),
        {
          status
        }
      );

    } catch (error) {

      console.log(error);

    }
  }

  async function deleteRequest(
    id: string
  ) {

    try {

      await deleteDoc(
        doc(
          db,
          "withdrawal_requests",
          id
        )
      );

    } catch (error) {

      console.log(error);

    }
  }

  if (loading) {

    return (

      <div className="flex min-h-screen items-center justify-center bg-[var(--card-color)] text-[var(--button-text-color)]">

        Loading...

      </div>

    );
  }

  return (

    <main className="min-h-screen bg-[var(--color-page-background)] p-4 text-[var(--button-text-color)]">

      {/* HEADER */}

      <div className="mb-8 flex items-center gap-4">

        <div className="flex h-16 w-16 items-center justify-center rounded-[24px] bg-[var(--success-color)]">

          <Wallet size={30} />

        </div>

        <div>

          <h1 className="text-3xl font-black">
            Withdrawal Requests
          </h1>

          <p className="mt-1 text-sm text-[var(--muted-text-color)]">
            Manage user withdrawal requests
          </p>

        </div>

      </div>

      {/* REQUESTS */}

      <div className="space-y-5">

        {requests.length === 0 && (

          <div className="rounded-[30px] bg-[var(--primary-color)] p-10 text-center">

            No Withdrawal Requests Found

          </div>

        )}

        {requests.map(
          (request) => (

            <div
              key={request.id}
              className="rounded-[30px] bg-[var(--primary-color)] p-5"
            >

              <div className="flex flex-col gap-6">

                {/* TOP */}

                <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">

                  <div>

                    <div className="flex items-center gap-3">

                      <User size={20} />

                      <h2 className="text-2xl font-black text-[var(--success-color)]">

                        {request.userName}

                      </h2>

                    </div>

                    <div className="mt-4 flex flex-col gap-2 text-[var(--text-color)]">

                      <div className="flex items-center gap-2">

                        <IndianRupee size={16} />

                        Amount:
                        {" "}
                        {request.amount}

                      </div>

                      <div>

                        Method:
                        {" "}
                        {request.method}

                      </div>

                      <div className="break-all">

                        Account:
                        {" "}
                        {request.account}

                      </div>

                    </div>

                  </div>

                  <StatusBadge
                    status={
                      request.status
                    }
                  />

                </div>

                {/* ACTIONS */}

                <div className="flex flex-wrap gap-3">

                  <button
                    onClick={() =>
                      updateStatus(
                        request.id!,
                        "Approved"
                      )
                    }
                    className="flex items-center gap-2 rounded-2xl bg-[var(--success-color)] px-5 py-3 font-bold text-[var(--text-color)]"
                  >

                    <CheckCircle2 size={18} />

                    Approve

                  </button>

                  <button
                    onClick={() =>
                      updateStatus(
                        request.id!,
                        "Rejected"
                      )
                    }
                    className="flex items-center gap-2 rounded-2xl bg-[var(--danger-color)] px-5 py-3 font-bold"
                  >

                    <XCircle size={18} />

                    Reject

                  </button>

                  <button
                    onClick={() =>
                      deleteRequest(
                        request.id!
                      )
                    }
                    className="flex items-center gap-2 rounded-2xl bg-[var(--card-color)] px-5 py-3 font-bold"
                  >

                    <Trash2 size={18} />

                    Delete

                  </button>

                </div>

              </div>

            </div>

          )
        )}

      </div>

    </main>

  );
}

function StatusBadge({
  status
}: {
  status: string;
}) {

  function getColor() {

    if (status === "Approved") {

      return "bg-[var(--success-color)]";

    }

    if (status === "Rejected") {

      return "bg-[var(--danger-color)]";

    }

    return "bg-[var(--warning-color)]";

  }

  function getIcon() {

    if (status === "Approved") {

      return <CheckCircle2 size={16} />;

    }

    if (status === "Rejected") {

      return <XCircle size={16} />;

    }

    return <Clock3 size={16} />;

  }

  return (

    <div
      className={`flex items-center gap-2 rounded-full px-5 py-3 text-sm font-bold ${getColor()}`}
    >

      {getIcon()}

      {status}

    </div>

  );
}
